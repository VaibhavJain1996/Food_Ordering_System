package shoppingCart.Dao;

import shoppingCart.Entity.Account;

public interface AccountDAO {
	public Account findAccount(String userName );
}
