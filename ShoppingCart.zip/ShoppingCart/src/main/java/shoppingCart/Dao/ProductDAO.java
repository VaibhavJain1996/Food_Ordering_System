package shoppingCart.Dao;

import shoppingCart.Entity.Product;
import shoppingCart.Model.PageResult;
import shoppingCart.Model.ProductInfo;

public interface ProductDAO {
	public Product findProduct(String code);
	   
    public ProductInfo findProductInfo(String code) ;
 
   
    public PageResult<ProductInfo> queryProducts(int page,
                       int maxResult, int maxNavigationPage  );
   
    public PageResult<ProductInfo> queryProducts(int page, int maxResult,
                       int maxNavigationPage, String likeName);

    public void save(ProductInfo productInfo);
}
