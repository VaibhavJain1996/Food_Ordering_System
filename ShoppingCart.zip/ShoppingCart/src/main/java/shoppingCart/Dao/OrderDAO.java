package shoppingCart.Dao;

import java.util.List;

import shoppingCart.Model.CartInfo;
import shoppingCart.Model.OrderDetailInfo;
import shoppingCart.Model.OrderInfo;
import shoppingCart.Model.PageResult;

public interface OrderDAO {
	public void saveOrder(CartInfo cartInfo);

    public PageResult<OrderInfo> listOrderInfo(int page,
            int maxResult, int maxNavigationPage);
   
    public OrderInfo getOrderInfo(String orderId);
   
    public List<OrderDetailInfo> listOrderDetailInfos(String orderId);

}
